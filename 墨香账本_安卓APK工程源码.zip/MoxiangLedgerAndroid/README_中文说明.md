# 墨香账本 Android 封装工程

这是把现有「墨香账本 · 3D 收藏室逐册版」封装为 Android WebView 应用的工程源文件。

## 当前状态
- 已放入升级版 HTML。
- 已开启 JavaScript、DOM 本地存储和网络访问。
- 已支持 JSON 文件导入选择器。
- 已将 CSV / JSON 导出接入 Android 下载目录。
- APK 需要由 Android SDK / Gradle 编译。本工程附带 GitHub Actions 工作流，可在 GitHub 云端编译 Debug APK。

## 重要：迁移旧账本数据
应用内 WebView 的本地存储与 Chrome 中打开 HTML 的存储空间相互独立。
请先在旧版账本中点击「备份 JSON」，保存备份文件；安装 APK 后点击「导入 JSON」，选择刚才的备份文件。

## 云端编译 APK（需要 GitHub 账号）
1. 在 GitHub 新建一个空仓库。
2. 将本工程 ZIP 解压，把里面所有文件上传到仓库根目录（保持 `.github/workflows/build-apk.yml` 路径不变）。
3. 打开仓库的 Actions 页面，选择 `Build Android APK`，点击 `Run workflow`。
4. 等待工作流完成，在该次运行页面底部的 Artifacts 下载 `MoxiangLedger-debug-apk`。
5. 解压得到 `app-debug.apk`，发送到安卓手机安装。首次安装时按系统提示允许安装此来源的应用。

## 说明
- 这是 Debug APK，适合个人安装测试；不是 Play 商店发布版。
- 页面中的书籍检索、封面/书脊 API、在线字体和 CDN 资源需要网络。
- 账本数据保存在应用本地 WebView 存储中。卸载应用可能清除未导出的数据，请定期备份 JSON。
